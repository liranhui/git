//
//  LRHBroswer.m
//  LRHBrowserPic
//
//  Created by sks on 16/3/9.
//  Copyright © 2016年 sks. All rights reserved.
//

#import "LRHBroswer.h"
#import "LRHPicView.h"
@implementation LRHBroswer
- (void)show
{
    UIWindow *window = [UIApplication sharedApplication].keyWindow;
    LRHPicView *picView = [[LRHPicView alloc]initLRHPicViewWithFrame:self.frame WithImages:nil imageNames:self.photos imageUrl:nil atIndex:self.currentPicIndex];
    
    [window addSubview:picView];
}

@end
