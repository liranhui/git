//
//  LRHPicView.m
//  LRHBrowserPic
//
//  Created by sks on 16/3/8.
//  Copyright © 2016年 sks. All rights reserved.
//

#import "LRHPicView.h"
#import "PicCell.h"
#define CellIdentifier    @"picCell"
@interface LRHPicView()<UICollectionViewDelegateFlowLayout,UICollectionViewDelegate,UICollectionViewDataSource,PicCellDelegate>
@end
@implementation LRHPicView
{
    UICollectionView         *_collectionView;
    UILabel                  *_picIndexLabel;
    NSArray                  *_imageNameArray;
    NSArray                  *_imageArray;
    NSArray                  *_imageUrlArray;
}
- (instancetype)initLRHPicViewWithFrame:(CGRect)frame WithImages:(NSArray*)images imageNames:(NSArray*)imageNames imageUrl:(NSArray*)urls atIndex:(NSInteger)index
{
    if(self == [super initWithFrame:frame])
    {
        if(images!=nil)
        {
            _imageArray = images;
        }
        if(imageNames!=nil)
        {
            _imageNameArray = imageNames;
        }
        if(urls!=nil)
        {
            _imageUrlArray = urls;
        }
        UICollectionViewFlowLayout *flowLayout = [[UICollectionViewFlowLayout alloc]init];
        flowLayout.minimumInteritemSpacing = 0;
        flowLayout.minimumLineSpacing = 0;
        [flowLayout setScrollDirection:UICollectionViewScrollDirectionHorizontal];
        _collectionView = [[UICollectionView alloc]initWithFrame:frame collectionViewLayout:flowLayout];
        _collectionView.delegate = self;
        _collectionView.dataSource = self;
        _collectionView.pagingEnabled = YES;
        [_collectionView registerNib:[UINib nibWithNibName:@"PicCell" bundle:nil] forCellWithReuseIdentifier:CellIdentifier];
        [self addSubview:_collectionView];
        //下方图片索引
        _picIndexLabel = [[UILabel alloc]initWithFrame:CGRectMake(0,KDeviceHight-40, KDeviceWidth, 40)];
        _picIndexLabel.textAlignment = NSTextAlignmentCenter;
        _picIndexLabel.textColor = [UIColor whiteColor];
        _picIndexLabel.font = [UIFont systemFontOfSize:16];
        [self insertSubview:_picIndexLabel aboveSubview:_collectionView];
        if(index>0)//跳到当前显示的图片
        {
            NSIndexPath *indexPath = [NSIndexPath indexPathForRow:index inSection:0];
            [_collectionView scrollToItemAtIndexPath:indexPath atScrollPosition:UICollectionViewScrollPositionLeft animated:NO];
        }
    }
    return self;
}

- (void)endBrowserPic
{
    [self removeFromSuperview];
}

- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView
{
    return 1;
}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    if(_imageArray!=nil)
    {
        return _imageArray.count;
    }
    if(_imageNameArray!=nil)
    {
        return _imageNameArray.count;
    }
    if(_imageUrlArray!=nil)
    {
        return _imageUrlArray.count;
    }
    else
    {
        return 0;
    }
}

- (UICollectionViewCell*)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    PicCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:CellIdentifier forIndexPath:indexPath];
    if(cell==nil)
    {
        cell = [[[NSBundle mainBundle]loadNibNamed:@"PicCell" owner:self options:nil] lastObject];
    }
    [cell.scrollView setZoomScale:1];
    cell.delegate = self;
    UIImage *image = [UIImage imageNamed:[_imageNameArray objectAtIndex:indexPath.row]];
    cell.picImage = image;
    _picIndexLabel.text = [NSString stringWithFormat:@"%ld/%lu",indexPath.row+1,(unsigned long)_imageNameArray.count];
    return cell;
}

-  (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath
{
    return CGSizeMake(self.frame.size.width, self.frame.size.height);
}
@end
