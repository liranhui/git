//
//  LRHBroswer.h
//  LRHBrowserPic
//
//  Created by sks on 16/3/9.
//  Copyright © 2016年 sks. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
@interface LRHBroswer : NSObject
@property (nonatomic,assign) CGRect            frame;
@property (nonatomic,strong) NSArray           *photos;//图片数组
@property (nonatomic,assign) NSInteger          currentPicIndex;//当前显示图片index


- (void)show;
@end
